

PATH_TO_PARTS = '/Volumes/4YP/wiki_parts'